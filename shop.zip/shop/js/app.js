var myApp = angular.module("shop",[
	"myApp.services",
	"myApp.controllers",
	"myApp.directives",
]);

var myCart = angular.module("cart",[
	"myApp.services",
	"myApp.controllers",
	"myApp.directives"
]);



