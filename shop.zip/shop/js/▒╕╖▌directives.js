var aj = angular.module("myApp.directives",[]);

aj.directive("shoplist",function(){
	return {
		restrict : "AE",
		scope : {cartObj : "=cartObj",deleteShop : "&",ev : "=myEvent"},
		template : '<table class="table table-bordered table-hover">' + 
				'<thead>' + 
					'<tr class="info">' + 
						'<td><input type="checkbox" />全选</td>' + 
						'<td>商品名称</td><td>商品单价</td>' + 
						'<td>购买数量</td><td>操作</td>' + 
					'</tr>' + 
				'</thead>' + 
				'<tbody>' + 
					'<tr ng-repeat="items in cartObj" class="getinfo-tr">' + 
						'<td><input type="checkbox" /></td>' + 
						'<td ng-bind="items.sname"></td>' + 
						'<td ng-bind="items.price"></td>' + 
						'<td ng-bind="items.buyNum"></td>' + 
						'<td><a href="javascript:;" data-sid={{items.sid}} ng-click="$parent.$parent.deleteShop(ev)">删除</a></td>' + 
					'</tr>' + 
				'</tbody>' + 
				'<tfoot>' + 
					'<tr class="success myshop">' + 
						'<td><a href="html/cart.html" target="_blank">我的购物车</a></td>' + 
					'</tr>' + 
				'</tfoot>' + 
			'</table>',
		replace:true,
	 	transclude:true, //处理指令里面的dom显示在哪里的
	 	link:function(scope, element, attrs){
	 		console.log(scope);
	 		
		}
	}
});




